"""Generate <available_skills> XML prompt block for agent system prompts."""

import html
from pathlib import Path

from .parser import ensure_safe_unicode, find_skill_md, read_properties


def _escape_xml(text: str) -> str:
    # XML normalizes literal CR/CRLF to LF. Character references preserve the
    # original parsed YAML text when the prompt is read by an XML consumer.
    return html.escape(text).replace("\r", "&#13;")


def to_prompt(skill_dirs: list[Path]) -> str:
    """Generate the <available_skills> XML block for inclusion in agent prompts.

    This XML format is what Anthropic uses and recommends for Claude models.
    Skill Clients may format skill information differently to suit their
    models or preferences.

    Args:
        skill_dirs: List of paths to skill directories

    Returns:
        XML string with <available_skills> block containing each skill's
        name, description, and location.

    Example output:
        <available_skills>
        <skill>
        <name>pdf-reader</name>
        <description>Read and extract text from PDF files</description>
        <location>/path/to/pdf-reader/SKILL.md</location>
        </skill>
        </available_skills>
    """
    if not skill_dirs:
        return "<available_skills>\n</available_skills>"

    lines = ["<available_skills>"]

    for skill_dir in skill_dirs:
        skill_dir = Path(skill_dir).resolve()
        props = read_properties(skill_dir)
        skill_md_path = find_skill_md(skill_dir)
        ensure_safe_unicode([props.name, props.description, str(skill_md_path)])

        lines.extend(
            [
                "<skill>",
                "<name>",
                _escape_xml(props.name),
                "</name>",
                "<description>",
                _escape_xml(props.description),
                "</description>",
                "<location>",
                _escape_xml(str(skill_md_path)),
                "</location>",
                "</skill>",
            ]
        )

    lines.append("</available_skills>")

    return "\n".join(lines)
