"""Tests for validator module."""

from pathlib import Path

import pytest

from skills_ref.validator import validate, validate_metadata


def test_valid_skill(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
---
# My Skill
""")
    errors = validate(skill_dir)
    assert errors == []


def test_nonexistent_path(tmp_path: Path):
    errors = validate(tmp_path / "nonexistent")
    assert len(errors) == 1
    assert "does not exist" in errors[0]


def test_not_a_directory(tmp_path: Path):
    file_path = tmp_path / "file.txt"
    file_path.write_text("test")
    errors = validate(file_path)
    assert len(errors) == 1
    assert "Not a directory" in errors[0]


def test_missing_skill_md(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    errors = validate(skill_dir)
    assert len(errors) == 1
    assert "Missing required file: SKILL.md" in errors[0]


def test_invalid_name_uppercase(tmp_path: Path):
    skill_dir = tmp_path / "MySkill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: MySkill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("lowercase" in e for e in errors)


def test_name_too_long(tmp_path: Path):
    long_name = "a" * 70  # Exceeds 64 char limit
    skill_dir = tmp_path / long_name
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(f"""---
name: {long_name}
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("exceeds" in e and "character limit" in e for e in errors)


def test_name_leading_hyphen(tmp_path: Path):
    skill_dir = tmp_path / "-my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: -my-skill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("cannot start or end with a hyphen" in e for e in errors)


def test_name_consecutive_hyphens(tmp_path: Path):
    skill_dir = tmp_path / "my--skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my--skill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("consecutive hyphens" in e for e in errors)


def test_name_invalid_characters(tmp_path: Path):
    skill_dir = tmp_path / "my_skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my_skill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("invalid characters" in e for e in errors)


def test_name_directory_mismatch(tmp_path: Path):
    skill_dir = tmp_path / "wrong-name"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: correct-name
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("must match skill name" in e for e in errors)


def test_unexpected_fields(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
unknown_field: should not be here
---
Body
""")
    errors = validate(skill_dir)
    assert any("Unexpected fields" in e for e in errors)


def test_valid_with_all_fields(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
license: MIT
metadata:
  author: Test
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_allowed_tools_accepted(tmp_path: Path):
    """allowed-tools is accepted as a supported optional frontmatter field."""
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
allowed-tools: Bash(jq:*) Bash(git:*)
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_i18n_chinese_name(tmp_path: Path):
    """Chinese characters are allowed in skill names."""
    skill_dir = tmp_path / "技能"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: 技能
description: A skill with Chinese name
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_i18n_russian_name_with_hyphens(tmp_path: Path):
    """Russian names with hyphens are allowed."""
    skill_dir = tmp_path / "мой-навык"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: мой-навык
description: A skill with Russian name
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_i18n_russian_lowercase_valid(tmp_path: Path):
    """Russian lowercase names should be accepted."""
    skill_dir = tmp_path / "навык"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: навык
description: A skill with Russian lowercase name
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_i18n_russian_uppercase_rejected(tmp_path: Path):
    """Russian uppercase names should be rejected."""
    skill_dir = tmp_path / "НАВЫК"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: НАВЫК
description: A skill with Russian uppercase name
---
Body
""")
    errors = validate(skill_dir)
    assert any("lowercase" in e for e in errors)


def test_description_too_long(tmp_path: Path):
    """Description exceeding 1024 chars should fail."""
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    long_desc = "x" * 1100
    (skill_dir / "SKILL.md").write_text(f"""---
name: my-skill
description: {long_desc}
---
Body
""")
    errors = validate(skill_dir)
    assert any("exceeds" in e and "1024" in e for e in errors)


def test_valid_compatibility(tmp_path: Path):
    """Valid compatibility field should be accepted."""
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
compatibility: Requires Python 3.11+
---
Body
""")
    errors = validate(skill_dir)
    assert errors == []


def test_compatibility_too_long(tmp_path: Path):
    """Compatibility exceeding 500 chars should fail."""
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    long_compat = "x" * 550
    (skill_dir / "SKILL.md").write_text(f"""---
name: my-skill
description: A test skill
compatibility: {long_compat}
---
Body
""")
    errors = validate(skill_dir)
    assert any("exceeds" in e and "500" in e for e in errors)


def test_nfkc_normalization(tmp_path: Path):
    """Skill names are NFKC normalized before validation.

    The name 'café' can be represented two ways:
    - Precomposed: 'café' (4 chars, 'é' is U+00E9)
    - Decomposed: 'café' (5 chars, 'e' + combining acute U+0301)

    NFKC normalizes both to the precomposed form.
    """
    # Use decomposed form: 'cafe' + combining acute accent (U+0301)
    decomposed_name = "cafe\u0301"  # 'café' with combining accent
    composed_name = "café"  # precomposed form

    # Directory uses composed form, SKILL.md uses decomposed - should match after normalization
    skill_dir = tmp_path / composed_name
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(f"""---
name: {decomposed_name}
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert errors == [], f"Expected no errors, got: {errors}"


def test_name_trailing_hyphen(tmp_path: Path):
    skill_dir = tmp_path / "my-skill-"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill-
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("cannot start or end with a hyphen" in e for e in errors)


def test_empty_name(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: ''
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("name" in e and "non-empty string" in e for e in errors)


def test_non_string_name(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name:
  - my-skill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert any("name" in e and "non-empty string" in e for e in errors)


def test_empty_description(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: ''
---
Body
""")
    errors = validate(skill_dir)
    assert any("description" in e and "non-empty string" in e for e in errors)


def test_non_string_description(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description:
  - invalid
---
Body
""")
    errors = validate(skill_dir)
    assert any("description" in e and "non-empty string" in e for e in errors)


def test_non_string_compatibility(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
compatibility:
  - Python 3.11
---
Body
""")
    errors = validate(skill_dir)
    assert any("compatibility" in e and "must be a string" in e for e in errors)


def test_empty_allowed_tools_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
allowed-tools: ''
---
Body
""")
    errors = validate(skill_dir)
    assert any("allowed-tools" in e and "non-empty string" in e for e in errors)


def test_non_string_allowed_tools_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
allowed-tools:
  - Bash(git:*)
---
Body
""")
    errors = validate(skill_dir)
    assert any("allowed-tools" in e and "non-empty string" in e for e in errors)


def test_lowercase_skill_md_does_not_satisfy_required_file(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "skill.md").write_text("""---
name: my-skill
description: A test skill
---
Body
""")
    errors = validate(skill_dir)
    assert errors == ["Missing required file: SKILL.md"]


def test_validate_relative_parent_path_resolves_directory_name(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    skill_dir = tmp_path / "my-skill"
    work_dir = skill_dir / "work"
    work_dir.mkdir(parents=True)
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
---
Body
""")

    monkeypatch.chdir(work_dir)

    assert validate(Path("..")) == []


def test_empty_markdown_body_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
---
""")
    errors = validate(skill_dir)
    assert any("Markdown content" in e for e in errors)


def test_non_string_license_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
license:
  - MIT
---
Body
""")
    errors = validate(skill_dir)
    assert any("license" in e and "must be a string" in e for e in errors)


def test_non_mapping_metadata_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
metadata: invalid
---
Body
""")
    errors = validate(skill_dir)
    assert any("metadata" in e and "must be a mapping" in e for e in errors)


def test_metadata_non_string_value_rejected():
    errors = validate_metadata(
        {
            "name": "my-skill",
            "description": "A test skill",
            "metadata": {"retries": 3},
        }
    )
    assert any("metadata[retries]" in e and "must be a string" in e for e in errors)


def test_metadata_non_string_key_rejected():
    errors = validate_metadata(
        {
            "name": "my-skill",
            "description": "A test skill",
            "metadata": {7: "seven"},
        }
    )
    assert any("metadata" in e and "keys must be strings" in e for e in errors)


def test_metadata_nested_sequence_value_rejected(tmp_path: Path):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text("""---
name: my-skill
description: A test skill
metadata:
  tags:
    - one
    - two
---
Body
""")
    errors = validate(skill_dir)
    assert any("metadata[tags]" in e and "must be a string" in e for e in errors)


@pytest.mark.parametrize(
    "value,valid", [("", False), (" ", False), ("x", True), ("x" * 500, True), ("x" * 501, False)]
)
def test_compatibility_exact_bounds(value: str, valid: bool):
    errors = validate_metadata({"name": "my-skill", "description": "Test", "compatibility": value})
    assert (errors == []) is valid


@pytest.mark.parametrize("name", [" my-skill", "my-skill ", "a" * 63 + "e\u0301"])
def test_raw_name_constraints_cannot_be_hidden_by_normalization(name: str):
    assert validate_metadata({"name": name, "description": "Test"})


def test_directory_read_failure_is_reported_as_validation_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    def denied(_path: Path):
        raise PermissionError("directory access denied")

    monkeypatch.setattr(Path, "iterdir", denied)
    errors = validate(tmp_path)
    assert len(errors) == 1
    assert "directory access denied" in errors[0]


@pytest.mark.parametrize("escape", [r"\U00110000", r"\UFFFFFFFF"])
def test_out_of_range_yaml_unicode_is_a_validation_error(tmp_path: Path, escape: str):
    skill_dir = tmp_path / "my-skill"
    skill_dir.mkdir()
    (skill_dir / "SKILL.md").write_text(
        f'---\nname: my-skill\ndescription: "{escape}"\n---\nBody',
        encoding="utf-8",
    )
    errors = validate(skill_dir)
    assert len(errors) == 1
    assert "Invalid YAML" in errors[0]
