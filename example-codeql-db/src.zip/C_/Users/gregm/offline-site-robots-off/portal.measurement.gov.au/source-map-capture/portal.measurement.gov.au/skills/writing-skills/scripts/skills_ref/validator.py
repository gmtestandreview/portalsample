"""Skill validation logic."""

import unicodedata
from collections.abc import Mapping
from pathlib import Path
from typing import cast

from .errors import ParseError
from .parser import find_skill_md, parse_frontmatter, read_skill_text

MAX_SKILL_NAME_LENGTH = 64
MAX_DESCRIPTION_LENGTH = 1024
MAX_COMPATIBILITY_LENGTH = 500

# Allowed frontmatter fields per Agent Skills Spec
ALLOWED_FIELDS = {
    "name",
    "description",
    "license",
    "allowed-tools",
    "metadata",
    "compatibility",
}


def _validate_name(name: object, skill_dir: Path | None) -> list[str]:
    """Validate skill name format and directory match.

    Skill names support i18n characters (Unicode letters) plus hyphens.
    Names must be lowercase and cannot start/end with hyphens.
    """
    errors: list[str] = []

    if not name or not isinstance(name, str) or not name.strip():
        errors.append("Field 'name' must be a non-empty string")
        return errors

    if len(name) > MAX_SKILL_NAME_LENGTH:
        errors.append(
            f"Skill name '{name}' exceeds {MAX_SKILL_NAME_LENGTH} character limit "
            f"({len(name)} chars)"
        )

    if name != name.strip():
        errors.append("Skill name cannot have leading or trailing whitespace")

    name = unicodedata.normalize("NFKC", name)

    if name != name.lower():
        errors.append(f"Skill name '{name}' must be lowercase")

    if name.startswith("-") or name.endswith("-"):
        errors.append("Skill name cannot start or end with a hyphen")

    if "--" in name:
        errors.append("Skill name cannot contain consecutive hyphens")

    if not all(c.isalnum() or c == "-" for c in name):
        errors.append(
            f"Skill name '{name}' contains invalid characters. "
            "Only letters, digits, and hyphens are allowed."
        )

    if skill_dir:
        dir_name = unicodedata.normalize("NFKC", skill_dir.name)
        if dir_name != name:
            errors.append(f"Directory name '{skill_dir.name}' must match skill name '{name}'")

    return errors


def _validate_description(description: object) -> list[str]:
    """Validate description format."""
    errors: list[str] = []

    if not description or not isinstance(description, str) or not description.strip():
        errors.append("Field 'description' must be a non-empty string")
        return errors

    if len(description) > MAX_DESCRIPTION_LENGTH:
        errors.append(
            f"Description exceeds {MAX_DESCRIPTION_LENGTH} character limit "
            f"({len(description)} chars)"
        )

    return errors


def _validate_compatibility(compatibility: object) -> list[str]:
    """Validate compatibility format."""
    errors: list[str] = []

    if not isinstance(compatibility, str):
        errors.append("Field 'compatibility' must be a string")
        return errors

    if not compatibility.strip():
        errors.append("Field 'compatibility' must be a non-empty string")

    if len(compatibility) > MAX_COMPATIBILITY_LENGTH:
        errors.append(
            f"Compatibility exceeds {MAX_COMPATIBILITY_LENGTH} character limit "
            f"({len(compatibility)} chars)"
        )

    return errors


def _validate_license(license_value: object) -> list[str]:
    """Validate license as a string when present."""
    if not isinstance(license_value, str):
        return ["Field 'license' must be a string"]
    return []


def _validate_metadata_value(metadata_value: object) -> list[str]:
    """Validate metadata as a string-to-string mapping when present."""
    if not isinstance(metadata_value, dict):
        return ["Field 'metadata' must be a mapping"]

    errors: list[str] = []
    metadata = cast(Mapping[object, object], metadata_value)
    for key, value in metadata.items():
        if not isinstance(key, str):
            errors.append("Field 'metadata' keys must be strings")
        if not isinstance(value, str):
            errors.append(f"Field 'metadata[{key}]' value must be a string")
    return errors


def _validate_allowed_tools(allowed_tools: object) -> list[str]:
    """Validate allowed-tools as a non-empty specification string."""
    errors: list[str] = []

    if not isinstance(allowed_tools, str) or not allowed_tools.strip():
        errors.append("Field 'allowed-tools' must be a non-empty string")

    return errors


def _validate_metadata_fields(metadata: Mapping[str, object]) -> list[str]:
    """Validate that only allowed fields are present."""
    errors: list[str] = []

    extra_fields = set(metadata.keys()) - ALLOWED_FIELDS
    if extra_fields:
        errors.append(
            f"Unexpected fields in frontmatter: {', '.join(sorted(extra_fields))}. "
            f"Only {sorted(ALLOWED_FIELDS)} are allowed."
        )

    return errors


def validate_metadata(metadata: Mapping[str, object], skill_dir: Path | None = None) -> list[str]:
    """Validate parsed skill metadata.

    This is the core validation function that works on already-parsed metadata,
    avoiding duplicate file I/O when called from the parser.

    Args:
        metadata: Parsed YAML frontmatter dictionary
        skill_dir: Optional path to skill directory (for name-directory match check)

    Returns:
        List of validation error messages. Empty list means valid.
    """
    errors: list[str] = []
    errors.extend(_validate_metadata_fields(metadata))

    if "name" not in metadata:
        errors.append("Missing required field in frontmatter: name")
    else:
        errors.extend(_validate_name(metadata["name"], skill_dir))

    if "description" not in metadata:
        errors.append("Missing required field in frontmatter: description")
    else:
        errors.extend(_validate_description(metadata["description"]))

    if "license" in metadata:
        errors.extend(_validate_license(metadata["license"]))

    if "compatibility" in metadata:
        errors.extend(_validate_compatibility(metadata["compatibility"]))

    if "metadata" in metadata:
        errors.extend(_validate_metadata_value(metadata["metadata"]))

    if "allowed-tools" in metadata:
        errors.extend(_validate_allowed_tools(metadata["allowed-tools"]))

    return errors


def validate(skill_dir: Path) -> list[str]:
    """Validate a skill directory.

    Args:
        skill_dir: Path to the skill directory

    Returns:
        List of validation error messages. Empty list means valid.
    """
    skill_dir = Path(skill_dir)

    if not skill_dir.exists():
        return [f"Path does not exist: {skill_dir}"]

    if not skill_dir.is_dir():
        return [f"Not a directory: {skill_dir}"]

    skill_dir = skill_dir.resolve()

    try:
        skill_md = find_skill_md(skill_dir)
        if skill_md is None:
            return ["Missing required file: SKILL.md"]
        metadata, body = parse_frontmatter(read_skill_text(skill_md))
    except ParseError as e:
        return [str(e)]

    errors = validate_metadata(metadata, skill_dir)
    if not body.strip():
        errors.append("SKILL.md must contain Markdown content after frontmatter")
    return errors
